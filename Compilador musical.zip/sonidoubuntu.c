#include<stdio.h>
#include<stdlib.h>
void main(void){



putc(0x07,stdout);
putc(0x07,stdout);
putc(0x07,stdout);
putc(0x07,stdout);
putc(0x07,stdout);
putc(0x07,stdout);




}
